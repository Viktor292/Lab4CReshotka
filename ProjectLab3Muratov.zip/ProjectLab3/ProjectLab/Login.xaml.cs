﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectLab
{
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_SignIn(object sender, RoutedEventArgs e)
        {

            SignIn login = new SignIn();
            login.Show();

        }
   
        bool CheckEmailAndPassword(string email, string password)
        {
            //string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\Users.txt";
            FileManager fm = new FileManager();
            Console.WriteLine("!!!! " + fm.GetTextFileAsyncVar());
            string[] users = fm.GetTextFileAsyncVar().Split(';');
            for (int i = 0; i < users.Length; i++)
            {
                try
                {
                    if (users[i].Split(' ')[0].Equals(email) && users[i].Split(' ')[1].Equals(password)) return true;
                }catch(Exception e)
                {
                    break;
                }
            }
            return false;
        }

        private void Button_Click_Login(object sender, RoutedEventArgs e)
        {
            if(CheckEmailAndPassword(Email.Text, Password.Password.ToString())) { 
            Wallets wallets = new Wallets(Email.Text);
            wallets.Show();
            this.Close();
            }
        }
    }
}







//Muratov