﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectLab
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class SignIn : Window
    {
        FileManager fm = new FileManager("Users");
        string usersAll = "";
        public SignIn()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        bool isValid(string email)
        {
            string pattern = "[.\\-_a-z0-9]+@([a-z0-9][\\-a-z0-9]+\\.)+[a-z]{2,6}";
            Match isMatch = Regex.Match(email, pattern, RegexOptions.IgnoreCase);
            return isMatch.Success;
        }

        static string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\Users.txt";

        bool CheckEmailNoPresentAsync(string email)
        {
            string data = fm.GetTextFileAsyncVar();
            usersAll = data;
            if (data == null) return true;
            String[] users = data.Split(';');
            for(int i = 0; i < users.Length; i++)
            {
                if (users[i].Split(' ')[0].Equals(email)) return false;
            }
            return true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (FirstNameTextBox.Text.ToString().Length > 4 && LastNameTextBox.Text.ToString().Length > 4 && FirstPasswordBox.Password.ToString().Equals(SecondPasswordBox.Password.ToString()) && isValid(EmailTextBox.Text) && CheckEmailNoPresentAsync(EmailTextBox.Text))
            {

                string writePath = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\Users.txt";

                string text = EmailTextBox.Text + " " + FirstPasswordBox.Password.ToString() + " " + FirstNameTextBox.Text + " " + LastNameTextBox.Text + ";";
                using (StreamWriter sw = new StreamWriter(writePath))
                {
                    sw.WriteLine(text);

                }
                fm.CreateFile(EmailTextBox.Text + ".txt");
                Console.WriteLine("New user created");
                SignInButton.Background = Brushes.Green;
                Login login = new Login();
                login.Show();
                this.Close();
            }
            else
            {
                SignInButton.Background = Brushes.Red;
            }
        }
    }
}





//Muratov