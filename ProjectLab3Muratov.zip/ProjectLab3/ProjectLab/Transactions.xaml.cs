﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProjectLab
{
    public partial class Transactions : Window
    {

        static string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\";
        string[] arrLine;
        FileManager fm;
        string mail;
        string walletMain;
        public Transactions(string text, string mailAdress)
        {
            path = path + text + ".txt";
            InitializeComponent();
            mail = mailAdress;
            walletMain = text;
            fm = new FileManager(text);
            arrLine = fm.GetTextFileAsyncArr();
            Console.WriteLine(fm.path);
            for (int i = 0; i < arrLine.Length; i++)
            {
                TransactionsList.Items.Insert(1, arrLine[i]);
            }
        }

        private bool NamePresent(string name)
        {
            for(int i = 0; i < arrLine.Length; i++)
            {
                Console.WriteLine(name);
                Console.WriteLine(arrLine[i].Split(' ')[0]);
                if(arrLine[i].Split(' ')[0].Equals(name)) return true;
            }
            return false;
        }

        private int NameIndex(string name)
        {
            for (int i = 0; i < arrLine.Length; i++)
            {
                if (arrLine[i].Split(' ')[0].Equals(name)) return i;
            }
            return -1;
        }

        private void AddClick(object sender, RoutedEventArgs e)
        {
        //    try
          //  {
                Console.WriteLine(NameBox.Text.Split(' ')[0]);
                string moneytype = "";
                if (EURBox.IsChecked == true) moneytype = "EUR";
                else moneytype = "USD";
                DateTime thisDay = DateTime.Today;
                string line = (arrLine.Length + 1) + " " + NameBox.Text + " " + SummBox.Text + " " + moneytype + " " + DescrBox.Text + " " + thisDay.ToString("g");
                TransactionsList.Items.Insert(1, line);
                Array.Resize(ref arrLine, arrLine.Length + 1);
                arrLine[arrLine.Length - 1] = line;
                string[] wallets = fm.GetTextFileAsyncVarOther(EmailBox.Text + ".txt").Split(';');
                Console.WriteLine(walletMain);
                for(int i = 0; i < wallets.Length; i++)
                {
                    string[] wallet = wallets[i].Split(' ');
                if (wallet[0].Equals(NameBox.Text))
                {
                    wallet[2] = (Int32.Parse(wallet[2]) + Int32.Parse(SummBox.Text)).ToString();
                    string result = "";
                    for (int j = 0; j < wallet.Length; j++)
                    {
                        result += wallet[j] + " ";
                    }
                    wallets[i] = result;
                    fm.ArrayToFileOther(wallets, EmailBox.Text + ".txt");
                }
                if (wallet[0].Equals(walletMain))
                {
                    wallet[2] = (Int32.Parse(wallet[2]) - Int32.Parse(SummBox.Text)).ToString();
                    string result = "";
                    for (int j = 0; j < wallet.Length; j++)
                    {
                        result += wallet[j] + " ";
                    }
                    wallets[i] = result;
                    fm.ArrayToFileOther(wallets, EmailBox.Text + ".txt");
                }
                //if (wallet[0].Equals(mail)) wallet[2] = (Int32.Parse(wallet[2]) - Int32.Parse(SummBox.Text)).ToString();
            }
                fm.ArrayToFile(arrLine);
                AddButton.Background = Brushes.Green;
            //  }
            //  catch (Exception exc) Int32.Parse(wallets[2]) 
            //  {
            //      AddButton.Background = Brushes.Red;
            // }
        }


        private void EditClick(object sender, RoutedEventArgs e)
        {
            try
            {
            string moneytype = "";
            if (EURBox.IsChecked == true) moneytype = "EUR";
            else moneytype = "USD";
            Console.WriteLine("Index selected " + TransactionsList.SelectedIndex);
            Console.WriteLine("Length selected " + arrLine.Length);
            DateTime thisDay = DateTime.Today;
            string line = (arrLine.Length + 1) + " " + NameBox.Text + " " + SummBox.Text + " " + moneytype + " " + DescrBox.Text + " " + thisDay.ToString("g");
            arrLine[TransactionsList.SelectedIndex - 1] = line;
            TransactionsList.Items.Remove(TransactionsList.SelectedItem);
            TransactionsList.Items.Insert(1, line);
            fm.ArrayToFile(arrLine);
                EditButton.Background = Brushes.Green;
            }
            catch (Exception exc)
            {
               EditButton.Background = Brushes.Red;
            }
        }

        private void RemoveClick(object sender, RoutedEventArgs e)
        {
            if (TransactionsList.SelectedIndex == -1)
            {
                RemoveButton.Background = Brushes.Red;
                return;
            }
            try
            {
                Console.WriteLine(TransactionsList.SelectedIndex);
                Console.WriteLine(arrLine.Length);
                var list = arrLine.ToList();
                list.Remove(TransactionsList.SelectedItem.ToString());
                arrLine = list.ToArray();
                TransactionsList.Items.Remove(TransactionsList.SelectedItem);
                fm.ArrayToFile(arrLine);
                RemoveButton.Background = Brushes.Green;
            }
            catch (Exception exc)
            {
                RemoveButton.Background = Brushes.Red;
            }
        }

        private void WalletsClick(object sender, RoutedEventArgs e)
        {
            Wallets wallets = new Wallets(mail);
            wallets.Show();
            this.Close();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}








//Muratov