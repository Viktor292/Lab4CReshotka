﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectLab
{
    class FileManager
    {
        string[] arrLine;
        string data;
        public string pathOrig = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\";
        public string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\";
        public FileManager(string text)
        {
            path = pathOrig + text + ".txt";
        }

        public FileManager()
        {
           
        }
        public string[] DeleteThisWord(string word, string[] mass)
        {
            for (int q = 0; q < mass.Length; q++)
            {
                if (mass[q] == word)
                {
                    mass[q] = null;
                    mass = mass.Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();
                }
            }
            return mass;
        }

        public void CreateFile(string name)
        {
            // Create the file, or overwrite if the file exists.
            using (FileStream fs = File.Create(pathOrig + name))
            {
                Console.WriteLine("Create file");
                byte[] info = new UTF8Encoding(true).GetBytes("");
                // Add some information to the file.
                fs.Write(info, 0, info.Length);
            }
        }

        public void RemoveFile(string name)
        {
            System.IO.File.Delete(pathOrig + name);

        }
        public string[] GetTextFileAsyncArr()
        {
            GetTextFileAsync();
            return arrLine;
        }

        public string GetTextFileAsyncVar()
        {
            GetTextFileAsyncVarIntro();
            return data;
        }

        public async void GetTextFileAsync()
        {
            string line;
            string data = "";
            using (StreamReader sr = new StreamReader(path))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    data += line;
                }
            }

            arrLine = DeleteThisWord("", data.ToString().Split(';'));

        }

        string data2;
        string[] arrLine2;
        public string GetTextFileAsyncVarOther(string pathText)
        {
            GetTextFileAsyncOther(pathText);
            return data2;
        }

        public async void GetTextFileAsyncOther(string pathText)
        {
            string line;
            using (StreamReader sr = new StreamReader(pathOrig + pathText))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    data2 += line;
                }
            }
        }

        async void GetTextFileAsyncVarIntro()
        {
            string path = @"C:\Users\Legion\source\repos\ProjectLab\ProjectLab\Users.txt";

            using (StreamReader sr = new StreamReader(path))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    data += line;
                }
                //Console.WriteLine(data.ToString());
            }
        }

        public void ArrayToFile(string[] arrLine)
        {
            using (StreamWriter sw = new StreamWriter(path))
            {
                for (int i = 0; i < arrLine.Length; i++)
                {
                    sw.Write(arrLine[i] + ";");
                }

            }
        }

        public void ArrayToFileOther(string[] arrLine, string fileName)
        {
            Console.WriteLine(pathOrig + fileName);
            using (StreamWriter sw = new StreamWriter(pathOrig + fileName))
            {
                for (int i = 0; i < arrLine.Length; i++)
                {
                    sw.Write(arrLine[i] + ";");
                }

            }
        }
    }
}


















//Muratov